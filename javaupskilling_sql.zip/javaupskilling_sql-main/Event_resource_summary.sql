CREATE TABLE Resources (
  resource_id INT,
  event_id INT,
  type VARCHAR(50)  -- e.g., 'PDF', 'Image', 'Link'
);
